#include "FigureColors.h"

float FigureColors::FigureTColor[] = {.5, .5, .5};
float FigureColors::FigureCubeColor[] = {.0, .5, .5};

FigureColors::FigureColors()
{
    //ctor
}

FigureColors::~FigureColors()
{
    //dtor
}
