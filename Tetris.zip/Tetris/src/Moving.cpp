#include "Moving.h"

Moving::Moving()
{
    //ctor
}

Moving::~Moving()
{
    //dtor
}
