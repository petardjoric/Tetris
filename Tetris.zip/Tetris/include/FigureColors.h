#ifndef FIGURECOLORS_H
#define FIGURECOLORS_H


class FigureColors
{
    public:
        FigureColors();
        virtual ~FigureColors();

        static float FigureTColor[3];
        static float FigureCubeColor[3];
};

#endif // FIGURECOLORS_H
